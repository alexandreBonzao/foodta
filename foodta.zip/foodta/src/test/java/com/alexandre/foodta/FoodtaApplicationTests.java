package com.alexandre.foodta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodtaApplicationTests {

	@Test
	void contextLoads() {
	}

}
