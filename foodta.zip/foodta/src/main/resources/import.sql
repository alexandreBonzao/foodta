insert into tb_cozinha(nome_cozinha) value ("Brasileira");
insert into tb_cozinha(nome_cozinha) value ("Italiana");
insert into tb_cozinha(nome_cozinha) value ("Tailandesa");