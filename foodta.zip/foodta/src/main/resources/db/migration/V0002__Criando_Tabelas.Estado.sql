create table tb_estado (
    id bigint not null auto_increment,
    nome_estado char(2),

    primary key(id)
) engine=InnoDB default charset=utf8;