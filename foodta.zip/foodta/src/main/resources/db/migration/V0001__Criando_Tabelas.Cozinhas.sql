create table tb_cozinhas (
    id bigint not null auto_increment,
    nome_cozinha varchar(70),

    primary key(id)
) engine=InnoDB default charset=utf8;


