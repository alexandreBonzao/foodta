package com.alexandre.foodta.infrastructure.repository;

import com.alexandre.foodta.domain.model.Cozinha;
import com.alexandre.foodta.domain.model.Estado;
import com.alexandre.foodta.domain.repository.EstadoRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EstadoRepositoryimpl implements EstadoRepository {

    @PersistenceContext
    private EntityManager manager;

    @Override
    public List<Estado> listar(){
        return  manager.createQuery("from Estado", Estado.class).getResultList();
    }

    @Override
    public Estado buscar(Long id) {
        return null;
    }

    @Override
    public Estado salvar(Estado estado) {
        return null;
    }

    @Override
    public void remover(Long id) {
        Estado estado = buscar(id);
        if (estado == null){
            throw new EmptyResultDataAccessException(1);
        }
        manager.remove(estado);

    }

}
