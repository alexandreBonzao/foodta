package com.alexandre.foodta.domain.service;


import com.alexandre.foodta.domain.exception.EntidadeEmUsoException;
import com.alexandre.foodta.domain.exception.EntidadeNaoEncontradaException;
import com.alexandre.foodta.domain.model.FormaPagamento;
import com.alexandre.foodta.domain.repository.FormaPagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class FormaPagamentoService {

    @Autowired
    private FormaPagamentoRepository formaPagamentoRepository;

    public FormaPagamento salvar(FormaPagamento formaPagamento) { return formaPagamentoRepository.salvar(formaPagamento);}

    public void excluir(Long id) {
        try {
            formaPagamentoRepository.remover(id);
        }
        catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("Forma de pagamento ou código %d não pode ser reovida, pois esta em uso.",id));
        }
        catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de forma de pagamento em código %d",id));
        }

    }
}
