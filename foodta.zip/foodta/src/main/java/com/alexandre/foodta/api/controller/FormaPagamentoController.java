package com.alexandre.foodta.api.controller;

import com.alexandre.foodta.domain.exception.EntidadeEmUsoException;
import com.alexandre.foodta.domain.exception.EntidadeNaoEncontradaException;
import com.alexandre.foodta.domain.model.Cozinha;
import com.alexandre.foodta.domain.model.FormaPagamento;
import com.alexandre.foodta.domain.repository.FormaPagamentoRepository;
import com.alexandre.foodta.domain.service.FormaPagamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/formaPagamento")
public class FormaPagamentoController {

    @Autowired
    private FormaPagamentoRepository formaPagamentoRepository;

    @Autowired
    private FormaPagamentoService formaPagamentoService;

    @GetMapping
    public List<FormaPagamento> listar() { return formaPagamentoRepository.listar();}

    @GetMapping("/formaPagamentoId")
    public ResponseEntity<FormaPagamento> buscar(@PathVariable Long formaPagamentoId){
        FormaPagamento formaPagamento = formaPagamentoRepository.buscar(formaPagamentoId);

        if (formaPagamento != null){
            return ResponseEntity.ok(formaPagamento);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{formaPagamentoId}")
    public ResponseEntity<Cozinha> remover(@PathVariable Long formaPagamentoId){
        try {
            formaPagamentoService.excluir(formaPagamentoId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public  FormaPagamento adicionar(@RequestBody FormaPagamento formaPagamento){
        return formaPagamentoService.salvar(formaPagamento);
    };
}
