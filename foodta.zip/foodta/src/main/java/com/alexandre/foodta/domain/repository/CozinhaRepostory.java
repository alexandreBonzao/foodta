package com.alexandre.foodta.domain.repository;

import com.alexandre.foodta.domain.model.Cozinha;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CozinhaRepostory {
    List<Cozinha> listar();
    Cozinha buscar(Long id);
    Cozinha salvar(Cozinha cozinha);
    void remover(Long id);
}
