package com.alexandre.foodta.domain.repository;

import com.alexandre.foodta.domain.model.Cozinha;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CozinhaRepostory extends JpaRepository<Cozinha, Long>  {
}
